SujoodSync account deletion page

Upload the entire `delete-account` folder to the root of the GitHub Pages
repository that serves https://privacy.rafflyn.com.

Expected published URL:
https://privacy.rafflyn.com/delete-account/

Before publishing:
- Confirm that Sujood Labs can meet the stated target of processing verified
  requests within 30 days.
- Implement the actual Firebase Authentication + Firestore deletion workflow.
- Ensure the support inbox netrafi007@gmail.com is monitored.
- Keep the subscription cancellation instructions accurate when Play Billing
  is introduced.
